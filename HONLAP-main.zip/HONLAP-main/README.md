<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Honlap</title>
    <link rel="stylesheet" href="stilus.css">
</head>
<body>
    <section id="banner">
        <div class="banner-text">
            <h1>Szűcs Gergő László</h1>
            <p>11/I osztályos tanuló az SZTE Ságvári Endre gimnáziumban</p>
            <div class="banner-btn">
                <a href="orarend.html"><span></span>Órarend</a>
                <a href="https://github.com/SzucsGergo1"><span></span>GitHub</a>
                <a href="https://github.com/SzucsGergo1/SAGVARI"><span></span>Projects</a>
            </div>
        </div>
    </section>
</body>
</html>
