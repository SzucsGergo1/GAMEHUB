let shopItemsData = [
  {
    id: "jfhgbvnscs",
    name: "Ing",
    price: 5000,
    desc: "Hétköznapi ing",
    img: "images/img-1.jpg",
  },
  {
    id: "ioytrhndcv",
    name: "Irodai ing",
    price: 12000,
    desc: "Prémium minőségű irodai ing",
    img: "images/img-2.jpg",
  },
  {
    id: "wuefbncxbsn",
    name: "Póló",
    price: 3800,
    desc: "Egyszerű póló",
    img: "images/img-3.jpg",
  },
  {
    id: "thyfhcbcv",
    name: "Öltöny",
    price: 40000,
    desc: "Elegáns öltöny",
    img: "images/img-4.jpg",
  },
];
